using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketData : ProjectileData
{
    protected override ProjectileTypes _ProjectileTypes => ProjectileTypes.Rockets;

}
