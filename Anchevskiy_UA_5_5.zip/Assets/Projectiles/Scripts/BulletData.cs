using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletData : ProjectileData
{
    protected override ProjectileTypes _ProjectileTypes => ProjectileTypes.Bullets;
}
