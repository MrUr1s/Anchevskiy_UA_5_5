﻿/// <summary>
/// Типы врагов
/// </summary>
public enum EnemyTypes { Big, Medium, Small }
/// <summary>
/// Типы снарядов
/// </summary>
public enum ProjectileTypes { Bullets, Rockets }

