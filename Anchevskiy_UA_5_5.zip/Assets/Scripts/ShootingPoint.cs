﻿using UnityEngine;
public class ShootingPoint:MonoBehaviour
{
}