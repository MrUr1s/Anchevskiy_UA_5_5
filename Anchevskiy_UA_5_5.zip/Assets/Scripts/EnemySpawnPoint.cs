﻿using UnityEngine;

public class EnemySpawnPoint: MonoBehaviour
{
}