﻿public interface IShoot
{
    public ProjectileTypes ProjectileType { get; }
}