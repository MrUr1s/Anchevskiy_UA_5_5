﻿public interface IHealth
{
    public int maxHealth { get; }
}