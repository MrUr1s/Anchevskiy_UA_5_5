using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMedium : EnemyData
{
    public override EnemyTypes EnemyType => EnemyTypes.Medium;
}
