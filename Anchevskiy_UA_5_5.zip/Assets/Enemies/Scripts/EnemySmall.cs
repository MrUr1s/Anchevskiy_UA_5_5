using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySmall : EnemyData
{
    public override EnemyTypes EnemyType => EnemyTypes.Small;
}
